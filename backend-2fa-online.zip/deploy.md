# Deploy Backend 2FA Online

## Passos
1. Subir para GitHub
2. Conectar no Render
3. Configurar variável DATABASE_URL com a URL do banco Neon
4. Comando de inicialização: node server.js
